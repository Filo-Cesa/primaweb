-- SQLite
INSERT INTO Prenotazioni (PrenotazioneId, Nome, Email)
VALUES (NULL,"tino","tino@gmail.it");

SELECT PrenotazioneId, Nome, Email
FROM Prenotazioni;